# Pitfalls and fixes

Each of these cost at least one full rebuild cycle the first time.

## Layout

**Positions taken from `\tikzmarknode` never settle.** The mark coordinates come from the `.aux` of the previous pass. If a node placed from `m1.center` counts towards the bounding box, pass 1 puts it at a wrong place, the page grows, pass 2 moves the mark, and so on. Fix: every node and path positioned from a mark gets `overlay`, and the picture has `remember picture`. If the render still looks stale, `latexmk -C name.tex` and rebuild from nothing; `build_figure.py` runs latexmk, which reruns as often as needed.

**`|-` inside a calc expression with a mark coordinate resolves wrongly.** `($(P3.north east)+(-0.3cm,0)$ |- m1.center)` puts the node in the wrong place with no error. Fix: `\coordinate (bx) at ($(P3.north east)+(-0.3cm,0)$);` then `(bx |- m1.center)`.

**Figure is 0.5pt too wide, only the paper log says so.** pdftex sees an included PDF about 1.5pt wider than `pdfinfo` reports. With three 4.35cm cards (391pt) the standalone `border` may add at most 4pt left+right: `border={1pt 3.5pt 3pt 1.5pt}` (left bottom right top). Check `grep -c Overfull main.log` after rebuilding the paper. Never scale with `width=` to compensate; it shrinks the fonts.

**Shadows cut off at the right or bottom.** Shadows are not in the bounding box; that is what the 3pt/3.5pt right and bottom borders are for. Keep them.

**A word in the document page hyphenates.** The `doc` style sets `execute at begin node={\hyphenpenalty=10000\relax}` (the braces are needed). If a word then overflows, shorten the sentence or widen `text width`; do not re-enable hyphenation.

**Table rows have different widths.** Give every column a `text width` in the matrix options. Header and data rows are measured separately otherwise.

**A footer text nearly touches the card edges.** Footer is 6.3pt; about 45 characters fit in a 4.35cm card, 40 in a 3.95cm card. Shorten the text; do not shrink the font below 6pt.

**Dotted table-to-class arrows pass through the table name.** Start them from the name node (`ben.north`), not from the matrix (`bemp2.north`).

**Cross-card alignment leaves one card half empty.** Place each card's content relative to its own card and accept different y positions across cards. Same-height pills and group labels are what the eye checks.

**The legend overhangs the cards and nothing warns.** The width verdict measures the page, and the legend is part of it, so a legend wider than the card row still passes as long as the page fits the text width. Budget it (0.11cm per character at 7pt, 0.46cm per swatch, `\legsep` between items) and, when it runs wide, shorten an item or `\renewcommand{\legsep}{\hspace{0.3cm}}`. For two cards use `\cardlegendspan{P1}{P2}{...}`.

**Straight quotes come out curly.** In the monospace font `'` is a right quote. Use `\textquotesingle` for SQL string literals and code.

**Indentation inside a code box disappears.** Leading spaces after `\\` are dropped. Indent with `~~` or reflow the line.

## Bar panels

**A system name runs into its icon.** `\barnamew` is a fixed column; the script sets it from the longest name, a hand-written file must. Budget 0.115cm per character at 7pt plus 0.15cm.

**The value label of the top bar is clipped or pokes past the other column.** `\barvaluew` reserves the space after a full-length bar. Four-digit values or a dagger need 0.85cm.

**Panels in the second row overlap the first.** `\barpanelpitch` is the distance between panel tops, not the gap: `\bartitlegap + rows*\barrowpitch + 0.5cm`. Recompute it when a panel gains a row.

**Bars in one panel look wrong compared with another.** `\barmax` is global on purpose. If one benchmark is on another scale, give that panel its own maximum (`\begin{barpanel}[10]...`) and put the unit in the title; do not change `\barmax` between panels.

**`\barrow` fails with `Missing number` or `Illegal unit`.** The value argument must be a plain number; a dagger, a percent sign or `--` belongs in the trailing optional label: `\barrow{Name}{}{88.3}[88.3$^\dagger$]`. A missing score is a missing row, not a zero bar.

**`\iconimg` cannot find the logo.** Paths are relative to the figure source; keep the logo files in `figures/` (or set `\graphicspath` in the figure file) and commit them with the source.

## Data plots (pgfplots)

**`Illegal parameter number in definition of \tikz@scan@point@coordinate` at `\end{axis}`, or a `\foreach` that draws all its paths at one place.** Paths inside an axis are executed at `\end{axis}`, when the `\foreach` variable is gone. Use `\pgfplotsinvokeforeach{0,1,2}{\draw ... (axis cs:#1,0) ...;}`, which substitutes `#1` textually, for `\draw` as well as for `\addplot`.

**A printed value comes out as `91.000000000`.** `visualization depends on={\thisrow{v} \as \cellv}` runs the cell through pgfmath. Write `visualization depends on={value \thisrow{v} \as \cellv}`; `value` keeps the text as written, and `\pgfmathtruncatemacro` can still test it.

**Digits in tick labels or printed values are in Computer Modern while the labels are sans.** pgfplots' default tick template is `$\pgfmathprintnumber{\tick}$`. The `paper` style replaces it with the text-mode template and sets `assume math mode=true`; a hand-written preamble must do the same, and a colour bar needs it in `colorbar style` because it is its own axis. Log axes then need `xticklabel=\axisdefaultticklabellog` or explicit `xticklabels={$10^2$,...}`.

**`File ended while scanning use of \pgfplotstableread@loop@next`.** An inline table must start on the line after `{` and the closing `}` must stand on its own line: `table {` newline `x y` newline rows newline `};`.

**The legend shows the default bar image, not the squares from `legend top`.** `ybar` and `xbar stacked` set their own `legend image code`. Put `legend top` after them in the option list.

**Row names vanish when the y axis is hidden.** `axis y line=none` removes the tick labels too. Use `y axis hidden` (axis line and ticks invisible, labels kept).

**Two direct labels overlap at the right edge.** Lines that end within about 4 points of each other need `yshift=3pt` on one label and `yshift=-3pt` on the other; there is no automatic repel.

**The flow diagram's quantity labels sit on a crossing.** `flows_from_csv.py` places them at 80% of the way to the target, where bands have fanned apart; raise `--label-min` to drop the small ones, or move a node by reordering rows in the CSV.

**`/tmp/...` paths in a Python heredoc on Windows.** Git Bash translates `/tmp/x` to the Windows temp directory only in command arguments; inside a Python script the string stays `/tmp/x` and the file is not found. Use the path the build script printed (`C:\Users\...\Temp\...`).

## Compile errors

**`Missing number, treated as zero ... \pgf@layerboxsaved@background`.** `\pgfsetlayers{background,shadow,main}` needs the `backgrounds` TikZ library. `cardfig.sty` loads it; a hand-written preamble must too.

**`Undefined control sequence \faFileAlt`.** Some fontawesome5 icons have an empty macro name. Use `\faIcon{file-alt}`; same for `share-alt`, `network-wired`, `book-open`, `project-diagram`.

**`drop shadow` does nothing on a matrix or a `rectangle split` node.** Both are drawn in pieces. Use `\boxshadow[]{name}` (square corners, for matrices) or `\boxshadow{name}` (2.5pt rounded, for class boxes); `\classbox` and `\classtag` already do it.

**`shadow opacity=0.45` makes the blur shadow invisible.** In `shadows.blur`, `shadow opacity` is a percentage (45). In `drop shadow`, `opacity` is a fraction (0.22).

**Nested `\tikz` inside a node.** Used by the legend helpers `\legswatch` and `\legline`. Works for a single node or path; do not put named nodes or `remember picture` inside them.

## Tooling

**Aux files land in the wrong directory.** Compile from the figure's directory (the build script does). Run `latexmk -c` afterwards; only `.tex` and `.pdf` are committed.

**Writing LaTeX through a Bash heredoc on Windows mangles backslashes** (`\\` collapses, `\f` becomes a form feed). Write and edit `.tex` files with the file tools, not with `cat <<EOF` or `sed`.

**The paper compiles but shows the old figure.** The PDF viewer is stale, or the figure PDF was not rebuilt, or the change is not pushed to Overleaf. Check the paper log for the figure's reported size (`<figures/name.pdf, id=..., 397pt x ...>`), then reopen the viewer.

**Reference figures to compare against.** SWE-bench Figure 1 (teaser.svg in the repository), Spider 2.0 Figure 1 and 2, BIRD Figure 1. Render an SVG with headless Chrome (`chrome --headless=new --screenshot`) via a small HTML wrapper when no other renderer is at hand.
