# Data plots (pgfplots) with plotfig.sty

`assets/plotfig.sty` gives pgfplots the same fonts and palette as the card figures and bakes in the conventions
that make a plot read well in print: only the left and bottom axis lines, a light horizontal grid, grey tick
labels, digits in the text font, series named at the line ends instead of in a legend box, one colour per system
across every figure of a paper. Nine finished plots with their renders sit in `assets/examples/plots/`; start
from the one closest to the chart at hand.

## Which chart

| question the figure answers | chart | example |
|---|---|---|
| how does a score grow with data, compute or time, for several systems | lines with confidence bands, direct labels | `curves-bands.tex` |
| how do a few systems compare on a few benchmarks, absolute values matter | grouped bars with the value on every bar | `grouped-bars.tex` |
| how much did we gain over the baseline, and where | dumbbell (paired dots with the gain printed) | `dumbbell.tex` |
| which systems are worth their cost | cost vs quality scatter with the Pareto frontier | `pareto.tex` |
| how does every source transfer to every target (any square matrix) | annotated heat map | `heatmap.tex` |
| what is each group made of, in shares | 100% stacked horizontal bars | `stacked-100.tex` |
| what is the dataset made of, one dimension at a time | donuts with the total in the hole | `donuts.tex` |
| where does the data flow, how do sources split into targets | flow diagram, generated from a CSV | `flows.tex` via `scripts/flows_from_csv.py` |
| how do systems compare on many capabilities at once | radar; use only when the text discusses the shape | `radar.tex` |
| how does our system rank on many benchmarks | bar panels (`barpanel`, cardfig.sty) | `assets/examples/bench-bars.tex` |

A bar chart with values printed needs no y axis. A line chart with direct labels needs no legend. A heat map
needs its numbers printed when the reader is meant to quote them. A radar chart is a legend in disguise, so keep
it to three systems and six axes at most.

## Styles in plotfig.sty

| style | what it does |
|---|---|
| `paper` (axis) | width 6cm, height 4cm, `scale only axis`, axes left and bottom only, grey ticks and labels, light y grid, `paper` cycle list, tick labels and values in the text font, `clip=false` |
| `y label top` | y label horizontal above the axis instead of rotated beside it |
| `legend top` | legend as a row of squares above the plot, no frame; put it **after** `ybar` or `xbar stacked` in the option list |
| `bars labelled` | for bar charts with `nodes near coords`: no y axis, no grid, values at 5.8pt monospace with one decimal |
| `y axis hidden`, `x axis hidden` | keep the tick labels (row names), draw neither the axis line nor the ticks |
| `dl`, `dlc` (TikZ) | direct label right of a line end / above a point, 6.5pt |
| `note`, `notearrow` | grey annotation text and its thin arrow |
| `ref` | dashed grey reference line (human, chance, previous best) |
| `mono` | 6pt monospace for printed numbers |
| cycle list `paper` | kept blue, addc orange, dbA teal, dbB violet, gold, grey; marks *, square, triangle, diamond, pentagon, o |

Colours: `kept` and `barblue` for ours (the bright `barblue` in bar and dot charts against grey, `kept` in line
charts), `addc` for a regression or a second system the text singles out, `black!20`/`black!45` for baselines
in bar charts, `bargrey` for a bar track. Bands use the series colour at `!14`.

## Sizes

| use | axis size | note |
|---|---|---|
| single plot in a two-column figure | width 6cm, height 4cm | fits `0.48\textwidth` with labels |
| two panels side by side (`groupplots`) | width 4.9cm, height 3.5cm, `horizontal sep=1.15cm` | 12.6cm total |
| bar chart across the text width | width 9.4cm, height 3.2cm | five groups of three bars at `bar width=0.3cm` |
| heat map | width = height = 4.6cm for 6 x 6 | 0.77cm per cell; colour bar adds 0.9cm |
| stacked bars | width 8.6cm, height 2.5cm for four rows | `bar width=0.34cm`, `enlarge y limits=0.18` |
| radar | 4.6cm | labels add about 1cm on every side |

`width`/`height` are the axis box because of `scale only axis`; labels and legends come on top. Set them in
the figure and include the PDF at natural size; scaling with `width=` in `\includegraphics` shrinks the fonts.

## Recipes

**Direct labels.** `\addplot ... coordinates {...} node[dl, text=kept] {Ours};` puts the name at the last
point. Give the axis `enlarge x limits={upper=0.4}` for the room. When two lines end within about 4 points of
each other, add `yshift=3pt` to one label and `yshift=-3pt` to the other.

**Confidence bands.** Two invisible paths and a fill, drawn before the line so the line sits on top:
```latex
\addplot[name path=u, draw=none, forget plot] coordinates {...upper...};
\addplot[name path=l, draw=none, forget plot] coordinates {...lower...};
\addplot[kept!14, forget plot] fill between[of=u and l];
```

**Reference line and annotation.** `\addplot[ref, forget plot] coordinates {(xmin,86) (xmax,86)} node[dl, text=black!55] {human};`
and one `note` with a `notearrow` for the finding the paragraph is about. One annotation, not three.

**Values on bars.** `bars labelled` plus `nodes near coords` on the axis; values are read from the y (or x)
coordinate. Numbers come out in the text font because the style sets `assume math mode=true`.

**Text in nodes near coords.** To print a table column as written (and to test it with `\ifnum`), read it with
`visualization depends on={value \thisrow{v} \as \cellv}` and use `\cellv`; without `value` the number is
printed as `91.000000000`. Skip small labels: `nodes near coords={\pgfmathtruncatemacro{\vv}{\cellv}\ifnum\vv>7 \cellv\fi}`.

**Heat map.** `matrix plot*` with `mesh/cols=N`, `point meta=explicit`, `y dir=reverse`, `enlargelimits=false`,
a single-hue colormap `colormap={paperblues}{color(0cm)=(white); color(1cm)=(kept)}` with fixed
`point meta min/max`, white text on cells above the midpoint, white 1pt grid lines and the diagonal outline
drawn with `\pgfplotsinvokeforeach`.

**Dumbbell.** Connectors as `\draw` in `axis cs` first, then one `only marks` plot per colour; the CI as
`error bars/.cd, x dir=both, x explicit` with `+- (ci,0)` after each coordinate; gains as `\node[dl, mono]`.

**Pareto frontier.** `const plot` through the non-dominated points, sorted by x, with the last point repeated at
`xmax`; the dominated region as a `\fill[barblue!7]` rectangle drawn before the plots.

**Stacked shares.** `xbar stacked`, one `\addplot table[x=v, y=row, meta=v]` per category, `point meta=explicit`;
the last (grey) category gets `every node near coord/.append style={text=black!70}` in its own options.

**Donuts.** `\donut{position}{centre text}{title}{value/colour/label, ...}` from `donuts.tex`; values in
percent, drawn clockwise from the top, label anchor picked by the sign of `cos(mid angle)`.

**Flows.** `python <skill>/scripts/flows_from_csv.py flows.csv --out figures/flows.tex` from a
`source,target,quantity` CSV; columns are inferred from the longest chain, nodes ordered by first appearance,
flow colour = source colour at 38% opacity, quantities printed near the target end of flows at least
`--label-min` (12) large.

**Radar.** `polaraxis` with `grid=none` and the polygon grid drawn by `\pgfplotsinvokeforeach`; close every
polygon by repeating the first point at 360; `fill opacity` 0.10 to 0.18; `legend image code` as squares.

**Two panels.** `groupplots` with `group style={group size=2 by 1, horizontal sep=1.15cm}`; options shared by
both panels go on the `groupplot` environment, the title on each `\nextgroupplot[title={...}]`.

## Checklist before including

- every series is named on the plot, or the legend sits above it as a row of squares
- the y label is horizontal above the axis (`y label top`) or dropped when the title says it
- digits are in the text font (no Computer Modern in tick labels or printed values)
- lines and bars are on top of bands, grids and tinted regions
- nothing in the figure is a claim the text does not make; one annotation at most
- `build_figure.py` says `width ok`, and the PNG shows no label touching another
