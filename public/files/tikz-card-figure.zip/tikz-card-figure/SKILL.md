---
name: tikz-card-figure
description: Paper figures as standalone TikZ/pgfplots documents in one house style (Source Sans Pro, Inconsolata, fixed palette, blue = ours). Three templates: (1) card-style teaser and method figures with dark title bars, pills, shadows and a running example; (2) benchmark bar panels, one panel per benchmark, bars sorted best first, generated from a CSV; (3) data plots: curves with confidence bands and direct labels, grouped bars with printed values, dumbbell gains, Pareto scatter, annotated heat maps, stacked shares, donuts, Sankey flows, radar. Use whenever the user asks for any paper figure or chart: teaser, Figure 1, overview, pipeline, method figure, results or leaderboard figure, plot of experiments, heat map, confusion matrix, Sankey, pie, radar, redrawing a Visio/PowerPoint/draw.io figure in TikZ, beautifying a TikZ figure, or says 画图, 先导图, 示意图, 方法图, 流程图, 美化这张图, 卡片风格, 同一风格, 柱状图, 条形图, 榜单图, 折线图, 热力图, 散点图, 雷达图, 桑基图, 饼图, 环形图, 实验图, even when TikZ or pgfplots is not mentioned.
---

# Card-style paper figures in TikZ

The style comes from the Figure 1 of SWE-bench, Spider 2.0 and BIRD: a row of cards, one point per card, a single concrete example running through all of them, text large enough to read at 100% zoom. What makes those figures work is restraint, a handful of big elements per card, and colour that carries the same meaning everywhere. The cards, bands and shadows are decoration around that; they make the figure look finished, but they cannot rescue a crowded one.

Everything visual lives in `assets/cardfig.sty` (palette, geometry, TikZ styles, macros). A figure file only places elements. Finished figures with their renders sit in `assets/examples/`; look at the PNGs before drawing, they are the target.

The same package holds a second template, **benchmark bar panels**, for results figures: a grid of small panels, one benchmark each, horizontal bars sorted best first with our system in blue. A sibling package, `assets/plotfig.sty`, styles **pgfplots data plots** (curves, bars, heat maps, scatter, stacked shares, donuts, flows, radar) with the same fonts and palette, so every figure of one paper sits together without a seam. The card workflow is sections 1 to 6 below; bar panels and data plots have their own sections after it.

## Workflow

### 1. Decide the content before writing any TikZ

Write down, in a few lines, the answers to these questions. The figure fails or succeeds here.

- **How many cards, and what is the one message of each.** The title is that message in one to three words. Cards are either *parallel points* (numbered badges that match an enumeration in the text, an orange pill per card) or *stages of a process* (plain titles, stage arrows in the gaps, footer bands that read as one sentence left to right).
- **The running example.** Take it from a listing, table or example already in the paper, so the reader meets the same names twice. Keep it tiny: two tables of two or three rows, two or three classes, one sentence of document.
- **What is orange.** Exactly the thing the paper claims is hard or new: the link the inputs do not state, the value no field holds, the element a step adds, the cell that changed. Everything else stays blue (target side, accepted result), teal/violet (two sources or two kinds of input) or grey (present but not in play). If two things want to be orange in one card, the card has two messages; split or cut.
- **The footer band.** What the card is contrasted with: the assumption of earlier work, the input, the previous stage. One short clause, lowercase, no period, under about 45 characters at 6.3pt.

### 2. Set up the files

- Copy `assets/cardfig.sty` next to the figure sources (usually `figures/`) if it is not there yet. The paper repository must contain its own copy; Overleaf compiles from the repository alone.
- Copy `assets/template.tex` to `figures/<name>.tex`. It has the class line with the right `border`, the geometry lengths, and commented placeholders for each element.
- Read `references/elements.md` for the building blocks and their code, and open the example source closest to the figure at hand (`teaser-points.tex` for parallel points, `pipeline-stages.tex` for stages, `io-two-cards.tex` for an input/output pair with a code block).

### 3. Place the elements

Plan each card on paper first with the size table in `references/elements.md` (row heights, characters per cm, legend width). The longest cell value and the legend decide the layout more often than anything else: a 13-character cell does not fit beside a document page, and a four-item legend does not fit under two narrow cards.

Place everything relative to its own card: `($(P1.north west)+(0.3cm,-1.2cm)$)`. The body area runs from `-\cardhh` (below the title bar) to `-\cardh+\cardfh` (above the footer); with pills, content ends above `-\cardh+\cardfh+0.55cm`. Keep 0.25 to 0.3cm from the card edges, and 0.9cm on the left when a connector runs down that side. Set `\cardh` once, for the tallest card.

Do not force elements in different cards onto the same coordinates when that leaves a large empty region in one card. Same *kind* of alignment matters more: pills at the same height (the macro does this), group labels on one line across a card, a result chip level with the row it comes from.

### 4. Build and look

```
python <skill>/scripts/build_figure.py figures/<name>.tex --png-dir /tmp/cardfig
```

The script compiles with latexmk from the figure's directory, cleans the aux files, prints the page size with a width verdict, and renders a PNG into `--png-dir` (default: the system temp directory; use `.` to deliver the PNG next to the source). On a compile error it prints the `!` lines with the `l.NN` line that locates them. Read the PNG with the Read tool every time; the log does not show overlaps, hyphenation or misalignment. Check:

- nothing touches or crosses a card edge; footer text has air on both sides
- no hyphenated word in a document page or a pill (the `doc` style forbids hyphenation; shorten the text instead of widening the page)
- table rows even (every column has a `text width`), highlighted cell border not clipped by its neighbour
- arrows leave from and arrive at the right anchors, none passes through a label or another cell
- shadows visible at the right and bottom (the standalone `border` leaves room; do not reduce it)
- width verdict `ok`; three 4.35cm cards with 0.35cm gaps are the maximum for a 5.5in text width
- a legend stays within the outer edges of the card row (the width verdict does not check this)

Iterate until the render is clean. Two or three rounds are normal.

### 5. Put it in the paper

- `\includegraphics{<name>.pdf}` with no width option; the figure is designed at text width and scaling changes the font sizes. `\graphicspath{{figures/}}` in the main file.
- The caption gives the reading key (what the colours mean, what the footer bands are) and what the figure cannot show on its own. It does not repeat the pills or the titles.
- Above the `figure` environment, add the project's usual comment block (in the paper's working language) recording what each card shows, the colour semantics, which listing the example comes from, and any decision a later editor should know.
- Rebuild the paper and check `grep -c Overfull <main>.log`; a figure 0.5pt too wide shows up there and nowhere else.
- Commit the PDF together with the source.

### 6. Revising a figure the user wants to compare

Write the new version to `<name>2.tex` and leave the old files untouched, then produce one stacked image:

```
python <skill>/scripts/compare_sheet.py --out /tmp/before-after.png "Figure 1, before=figures/<name>.pdf" "Figure 1, after=figures/<name>2.pdf"
```

Deliver that PNG, switch the `\includegraphics` to the new file, and say which elements were added, moved or removed.

## Benchmark bar panels (results figures)

The target is `assets/examples/bench-bars.png`: a 2 x 3 grid of panels, each a bold benchmark name over six rows, each row a system name, a small logo, a grey bar and the score in monospace at the bar's end. Our system's bar is blue. There are no axes, ticks or grid lines; every bar in the figure is drawn on the same scale (`\barmax`, 100 for percentages), so a short bar in one panel means a low score, not a different axis.

1. **Put the numbers in a CSV**, one row per system, one column per benchmark, an optional `icon` column (`letter:K`, `letter:K:kept`, `fa:sun:addc`, `img:logos/x.pdf`, or raw LaTeX). Take the numbers from the paper's results table so figure and table agree to the decimal.
2. **Generate the figure file:**
   ```
   python <skill>/scripts/bars_from_csv.py results.csv --ours "Ours" --cols 2 --out figures/<name>.tex
   ```
   The script sorts every panel best first (`--lower-better "Latency"` for metrics where less is better), paints the `--ours` system blue, sets `\barnamew` from the longest name, `\barpanelpitch` from the largest row count and `\barmax` from the value range (`--max` to force it). Panels fill the grid left to right, then down, in CSV column order; reorder the columns to reorder the panels.
3. **Build and look** with `build_figure.py` as for cards. Check that no name touches its icon (raise `\barnamew`), that the longest value label stays inside the panel width (raise `\barvaluew`), that the panels have the same air between them vertically and horizontally, and that the title is not wider than the panel.
4. **Include** with `\includegraphics{<name>.pdf}` and no width option. The caption names the metric of each panel when the titles do not, states that the blue bar is our system and that bars share one scale, and does not repeat the winners.

Hand-written panels use the same macros (see `assets/template-bars.tex`): `\begin{barpanel}{col}{row}{Title}` with zero-based grid positions, and one `\barrow[ours]{name}{icon}{value}` per system, best first. A panel on another scale takes `\begin{barpanel}[10]{...}`; a printed label that differs from the number goes in a trailing optional argument, `{88.3}[88.3$^\dagger$]`. Three columns fit at `\barpanelw` 4.2cm; a single panel at text width is a bar chart with very long bars, so use one or two columns.

Rules that differ from the card template: no shadows, no frames, black text, and its own two colours, the bright `barblue` (007DFF) for ours against `bargrey` (E7E7E7) for everyone else (orange `ours2` for one more system that the text singles out, such as an ablation). Do not swap in the card blue; it reads as dull beside grey bars. Logos are decoration; when a system has none, leave the icon empty rather than inventing one. Never sort by anything but the value shown.

## Data plots (pgfplots)

`assets/plotfig.sty` is loaded instead of `cardfig.sty` (copy it into `figures/` too). Its `paper` axis style sets what the guidelines in the PGF manual and Tufte ask for: axis lines left and bottom only, a light horizontal grid, grey tick labels, digits in the text font, the y label horizontal above the axis, series named at their line ends, one colour per system reused across all figures. The nine renders in `assets/examples/plots/` are the target; `references/plots.md` says which chart answers which question, lists every style, and gives the recipe for each chart.

1. **Pick the chart from the question the paragraph asks**, with the table in `references/plots.md`. Growth over data or time: lines with bands. A few systems on a few benchmarks: grouped bars with printed values. Gains over a baseline: dumbbell. Cost against quality: Pareto scatter. A square matrix: heat map. Shares: 100% stacked bars or donuts. Where data goes: flows. Our rank on many benchmarks: bar panels (previous section).
2. **Copy the closest example** from `assets/examples/plots/` (or `assets/template-plot.tex` for a plain line chart) to `figures/<name>.tex`, replace the data, keep the sizes unless the figure has a different slot. Flow diagrams are generated: `python <skill>/scripts/flows_from_csv.py flows.csv --out figures/<name>.tex`.
3. **Name every series on the plot** (`node[dl] {Ours}` at the line end, `legend top` for bars), print values where the reader will quote them, add at most one annotation, and one reference line if the text compares against one (human, chance, previous best).
4. **Build with `build_figure.py`**, read the PNG, and check the list at the end of `references/plots.md`: no two labels touch, no Computer Modern digits, lines above bands and grids.
5. **Include** at natural size; the caption names the metric and the colour meaning once (ours is blue in every figure), and does not repeat what the direct labels already say.

## Design rules

- **Type sizes.** Title 8.5pt bold, body 6.5 to 7pt, footer 6.3pt, never below 6pt. Identifiers (table, column, class, file names) in the monospace font; prose in the sans.
- **One shadow system.** Cards get the blurred shadow, every inner element gets the 0.7pt hard shadow (`sh` style, or `\boxshadow` for matrices and class boxes). An element without a shadow looks pasted on; a second shadow style looks like two figures glued together.
- **Colour is semantic.** Blue `kept` for the target side and for what is kept, accepted or extracted; orange `addc` for the difficulty or for what a step adds; teal `dbA` and violet `dbB` for two sources or two kinds of input (teal alone when there is one); grey for present-but-not-in-play. Keep the same meaning across all figures of one paper, and give the meaning in the first caption or a legend.
- **Names carry the story.** Source-side names look like the source (`id`, `unit`, `parse.py`), target-side names like the target (`Employee`, `inUnit`, `resolved`), so the reader sees the gap the system has to bridge without being told.
- **Icons.** fontawesome5 for abstract notions in title bars and group labels (`database`, `sitemap`, `cubes`, `bug`, `code`, `vial`, `key`, `file-alt`, `code-branch`); the drawn cylinder `\dbicon` for databases in the body, because it takes the source colour. Icons decorate; they never replace a label.
- **Text in the figure.** Sentence case for titles, lowercase for footers and pills, no terminal periods, no abbreviations the paper does not use. A pill is one clause; if it needs a comma, it is two messages.
- **Nothing the paper text does not say.** The figure shows the problem or the procedure; it does not explain a method or a score unless the surrounding section does.

## Pitfalls

The ones that cost the most time are listed with their fixes in `references/pitfalls.md`. The two that bite first: elements positioned from `\tikzmarknode` coordinates need `overlay`, or the page never converges; and the standalone `border` plus card widths must stay under the text width minus 1.5pt, because pdftex sees included PDFs slightly wider than `pdfinfo` reports.

## Files

- `assets/cardfig.sty`: palette, geometry lengths, layers, all TikZ styles (tables `tblA/tblB/tblK`, chips, `code`, class boxes, edges, `caplab`), and the macros `\cardpanels`, `\cardhead`, `\cardheadn`, `\cardicon`, `\cardfoot`, `\cardpill`, `\cardstage`, `\cardlegend`, `\cardlegendspan`, `\boxshadow`, `\pageshadow`, `\foldcorner`, `\dbicon`, `\dbchip`, `\classbox`, `\classtag`, `\docpage`, `\keyic`; plus the bar-panel template: lengths `\barpanelw`, `\barcolgap`, `\barpanelpitch`, `\barnamew`, `\bariconw`, `\barvaluew`, `\barrowpitch`, `\barh`, `\bartitlegap`, macro `\barmax`, environment `barpanel`, command `\barrow`, icon helpers `\iconletter`, `\iconfa`, `\iconimg`.
- `assets/plotfig.sty`: pgfplots counterpart of cardfig (same fonts and palette): axis style `paper`, `y label top`, `legend top`, `bars labelled`, `y axis hidden`, `x axis hidden`, cycle list `paper`, TikZ styles `dl`, `dlc`, `note`, `notearrow`, `ref`, `mono`.
- `assets/template.tex`: card skeleton to copy.
- `assets/template-bars.tex`: bar-panel skeleton to copy (or generate the file with `bars_from_csv.py`).
- `assets/template-plot.tex`: line-chart skeleton with direct labels and a reference line.
- `assets/examples/plots/` (+ `.png` each): `curves-bands` (two panels, confidence bands, direct labels, annotation), `grouped-bars` (values on bars, legend as squares), `dumbbell` (gains with CI), `pareto` (log x, frontier, dominated region), `heatmap` (annotated transfer matrix, colour bar), `stacked-100` (shares with printed percentages), `donuts` (three composition donuts, pure TikZ), `flows` (+ `flows.csv`; generated), `radar` (polygon grid, three systems).
- `assets/examples/teaser-points.tex` (+ `.png`): three parallel points with badges and pills; document page with highlighted phrases, chips, question badges, a table with a highlighted cell.
- `assets/examples/pipeline-stages.tex` (+ `.png`): three stages with stage arrows; tables with a foreign key and a greyed table, class boxes with key icons, dotted derivation arrows, an added superclass, legend.
- `assets/examples/io-two-cards.tex` (+ `.png`): two cards, input and output; question page, schema tables, code block with highlighted tokens, blue result table, legend spanning both cards.
- `assets/examples/bench-bars.csv`, `bench-bars.tex` (+ `.png`): six benchmarks in a 2 x 3 grid, six systems, letter and icon logos, generated from the CSV.
- `references/elements.md`: every card and bar-panel building block with its code and the reason for its shape.
- `references/plots.md`: which chart for which question, the plotfig styles, sizes, one recipe per chart, checklist.
- `references/pitfalls.md`: compile and layout problems and their fixes, including the pgfplots ones.
- `scripts/build_figure.py`: compile, clean, width check, PNG render.
- `scripts/bars_from_csv.py`: results CSV to a sorted bar-panel figure file.
- `scripts/flows_from_csv.py`: source,target,quantity CSV to a flow (Sankey-style) diagram file.
- `scripts/compare_sheet.py`: stacked before/after image.
